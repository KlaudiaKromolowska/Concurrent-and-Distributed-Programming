Program napisany na podstawie materiałów dydatkycznych dr Jacka Piwowarczyka. 
Zmian dokonali: Klaudia Kromołowska i Anton Bohatiuk

http://home.agh.edu.pl/~jpi/dokuwiki/doku.php?id=dydaktyka:pwir:2018:start